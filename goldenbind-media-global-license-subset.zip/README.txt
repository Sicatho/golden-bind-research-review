GoldenBind reusable-media starter library — 17 November 2026

These are actual downloaded source assets for research cards and a future welcome video. No AI media, video edit, render, music selection, social post, account creation or public upload was performed.

Authoritative inventory: ../media-manifest.json. Technical and rights holds: ../media-audit.json. Source/setup notes: ../media-sources.json. Visual index: ../media-contact-sheet.html. Each asset has a compact item-specific JSON receipt in license-evidence/; ready-to-copy credit lines are in CREDITS.txt.

All final crossposting remains on HOLD until the script, context, credits and visual/audio review are complete. A worldwide CC0 or CC BY license clears the stated copyright license only; it does not imply institutional endorsement or clear unidentified third-party rights. Public-domain items are held for jurisdiction/reproduction checks before US/Canada/worldwide publication. Never equate an old date, a hosting institution or free download with worldwide public-domain rights.

CC BY assets: retain creator, source URL and license URL and identify later changes. CC0/public-domain credits are retained for provenance. Original filenames are preserved. Some stills are server-supplied Wikimedia size derivatives; those records say so. Local files were not cropped, recolored, composited or otherwise edited. The contact sheet displays source images and browser-controlled video without creating derivative media.

Four short clips use the original WebM/Ogg source containers. Source duration/dimensions and local hashes/container signatures are recorded. No frame/audio playback review or transcoding was performed. Check and, only when authorized to edit, remove any unsuitable incidental audio before use. Native Ogg Theora may require import support in a chosen editor.

HTTP 429 responses were honored with bounded backoff. Where the server explicitly recommended documented thumbnail sizes, normal official 1280px derivative URLs were used in a separate bounded retrieval. No CAPTCHA, token, login, TLS, browser-download or paid-access restriction was bypassed.

The complete family archive includes held research references. A separate global-license subset archive, when present, excludes PD/uncertain-context items and still requires the parent's visual/context check before hosting. Do not use the complete archive itself as a public crossposting bundle.
